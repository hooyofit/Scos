# Somali Capability Atlas — Portable Edition v1.0

Downloadable, runnable copy of the FROZEN Somali Capability Atlas
(Stages 1–15 complete, Stage 15r1 correction included).

This package contains NO application changes. The `somali-capability-atlas/`
folder is byte-identical to the frozen build at git commit `84da0b7`
("Stage 15 correction v1.0"). The only additions are these distribution files.

## What is in this package

| Item | Location | Notes |
|---|---|---|
| Application source (204 files) | `somali-capability-atlas/` | HTML/CSS/JS PWA, no build step required |
| Seeded data (240 capabilities, 12 families) | `somali-capability-atlas/data/` | loads automatically |
| JSON schemas | `somali-capability-atlas/schemas/` | Stage 1 canonical set |
| Tests (23 suites, 10,927 checks) | `somali-capability-atlas/tests/` | `node tests/run-all.js` |
| Documentation | `somali-capability-atlas/docs/` | architecture + stage docs |
| Provenance & hashes | `PROVENANCE.txt` | commits, sha256, frozen-stage table |
| GitHub starter kit | `github-kit/` | README, .gitignore, deployment guide |

## How to run

### Option A — local static server (recommended)

    cd somali-capability-atlas
    python3 -m http.server 8421
    # open: http://127.0.0.1:8421/index.html

Any static file server works (python, `npx serve`, nginx, etc.).
Over http://localhost the service worker registers and the app
becomes installable as a PWA with offline precache.

### Option B — static HTTPS host (GitHub Pages or any static host)

Copy the CONTENTS of `somali-capability-atlas/` to the web root
(for GitHub Pages: the repo root or `/docs`). No server code needed.
The app is fully static: HTML + JS + JSON data files.

### Option C — file:// (opens directly, with limits)

Double-click `somali-capability-atlas/index.html`.
The application boots and all data loads, but:

- the service worker does NOT register on file:// (browser security
  rule, documented in the app: `src/app.js` registerServiceWorker);
- PWA install and offline precache are therefore unavailable;
- everything else works, using browser localStorage.

No server code, database, or network service is required for any
option. The app is fully self-contained.

## IMPORTANT — known route-navigation defect (pre-existing, frozen)

The frozen build contains a defect present since Stage 1:

**The hash router can never match any route.** Route patterns are
stored WITH their leading `#` (`'#/capabilities'.split('/')` →
`["#", "capabilities"]`) but the incoming hash is compared with the
`#` stripped (`'#/capabilities'.replace(/^#/,'').split('/')` →
`["", "capabilities"]`). The first segment can never be equal, so
every URL shows the "Page not found" page.

Consequences when you open the app:

- the app boots fully (data loads, 240 capabilities present, navbar
  and footer render);
- clicking any navigation link shows "Page not found".

The application logic beneath the router is intact and fully
functional (verified: all 24 page handlers render correctly when
invoked directly; 10,927 automated checks pass).

This defect is REPORTED, not repaired. Per the frozen-build rules,
no application code was changed for this distribution. The smallest
correction (one line in `src/router/router.js`) requires a separate
owner authorization, together with two smaller latent defects found
in the same audit (details in the accompanying report).

## Data ownership

Everything needed to run the Atlas is inside `somali-capability-atlas/`.
This package does not depend on any cloud service, account, API key,
or sandbox. Your data (once entered) lives in the browser's
localStorage and can be exported as JSON from within the app
(Export page, requires a role with data.export permission).

## Version identification

- Application: Somali Capability Atlas, BUILD_STEP 15
- Frozen stage lineage: Stages 1–15 all frozen (see PROVENANCE.txt)
- Source commit: 84da0b7 (byte-identical tree in this zip)
- Portable package: portable-v1.0
