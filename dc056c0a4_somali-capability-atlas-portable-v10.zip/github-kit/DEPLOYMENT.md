# Backup & Deployment Guide

## GitHub (recommended primary backup)

1. Create an empty repository on GitHub (private recommended).
2. From the app root:

   ```bash
   cd somali-capability-atlas
   git init                      # skip if already a git repo
   git add .
   git commit -m "Somali Capability Atlas — frozen Stages 1-15 (84da0b7)"
   git remote add origin https://github.com/<you>/<repo>.git
   git push -u origin main
   ```

3. Copy `../github-kit/.gitignore` and `../github-kit/README.md`
   into the repo root if starting from the portable zip.
4. Optional: the full pre-transfer history (77 commits) is available
   in the separately delivered `somali-capability-atlas-history.bundle`
   (git bundle). Restore with:
   `git clone somali-capability-atlas-history.bundle atlas-from-history`

## GitHub Pages deployment

- Repo → Settings → Pages → Deploy from branch → main / root.
- The app serves at `https://<you>.github.io/<repo>/`.
- Over https the service worker registers; the app is then
  installable and offline-capable on phones.

## Other static hosts

Netlify / Vercel / Cloudflare Pages: drag-and-drop the app folder;
no build command, publish directory = repo root. Any nginx/Apache
docroot works by copying the files.

## Backup checklist

- [ ] GitHub repo created, app pushed, verified clone boots
- [ ] JSON export downloaded from the app (after entering real data)
- [ ] git bundle (history) stored on a second medium
- [ ] portable zip stored offline (contains everything)

## Recovery

The application needs only a static server and the files in this
package. Re-clone from GitHub, or unzip the portable package, and run
Option A (see PORTABLE-README.md). All seed data ships with the app.
