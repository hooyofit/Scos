# Somali Capability Atlas

An evidence-based capability atlas connecting Somali knowledge, people,
technology, repair, training and resilience. A portable, offline-first
PWA: no backend, no account, no build step.

**Build:** frozen Stages 1–15 · commit `84da0b7` · 10,927 automated checks / 21 suites / 0 failures

## Run locally

```bash
# any static server works; e.g.
python3 -m http.server 8421
# open http://127.0.0.1:8421/index.html
```

Or simply open `index.html` directly (file:// works; the service worker
and PWA install are disabled on file:// by browser rules — see
`src/app.js`).

## Test

```bash
node tests/run-all.js     # 10,927 checks, 21 suites
```

## Deploy (static hosting)

Everything is static. Copy the repository contents to any static host:
GitHub Pages, Netlify, any nginx/apache docroot. Over https:// the
service worker registers and the app is installable/offline-capable.

## Data

- Ships with a seed inventory: 240 capabilities in 12 families.
- User data lives in the browser (localStorage) and is exported as
  JSON from the in-app Export page (role-gated).
- No fabricated values: unknown fields read "Not yet documented".

## Documentation

See `docs/` (architecture, stage docs) and `README.md` in the app root.

## Provenance

See `PROVENANCE.txt` (frozen-stage lineage, hashes, quality baseline).
Stages 1–15 are frozen; changes require explicit owner authorization.

## Ethical layer

The Atlas is designed under a Qur'anic ethical frame — stewardship
(khilafah), amanah (trust), avoidance of waste, justice, verification
before claims ("Do not follow that of which you have no knowledge",
Qur'an 17:36), honest measurement, consultation (shura), human dignity,
and responsibility toward future generations. It is an ethical compass
for the architecture, not a technical proof system. It appears in the
record honesty rules (no fabrication, "Not yet documented" defaults),
review/verification gates, consent and privacy rules in field
research, and the governance documents.
